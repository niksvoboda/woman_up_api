class taskController{
    show(req, res) {
        res.json('TASKCONTROLLER')
    }
}



module.exports = new taskController