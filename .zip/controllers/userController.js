class userController{
    show(req, res) {
        res.json('USERCONTROLLER')
    }
}



module.exports = new userController