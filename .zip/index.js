const express = require('express')
require('dotenv').config()
const cors = require('cors')
const path = require('path')
const PORT = process.env.PORT
const router = require('./routes/index.js')

const app = express()
app.use(cors())
app.use(express.json())
app.use(express.static(path.resolve(__dirname, 'static')))
app.use('/api', router)

const start = () =>{
    try{
        app.listen(PORT, () => console.log('start on: '+ PORT))
    } catch(e) {
        console.log(e)
    }
}

start()