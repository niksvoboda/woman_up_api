const Router  = require('express')
const router = new Router()
const userController = require('../controllers/userController')
const taskController = require('../controllers/taskController')

router.get('/user', userController.show)
router.get('/task', taskController.show)

module.exports = router